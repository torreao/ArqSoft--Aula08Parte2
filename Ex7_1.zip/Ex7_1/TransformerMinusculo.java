package Ex7_1;

import javax.swing.JOptionPane;

public class TransformerMinusculo extends TransformerString {
	private String texto;
	
	@Override
	public void LerString() {
		texto = JOptionPane.showInputDialog("");
	}

	
	@Override
	public void ImprimirString() {
		JOptionPane.showMessageDialog(null,""+ texto);
	}

	@Override
	public void TransformarString() {
		texto = texto.toLowerCase();
		
	} 

}
