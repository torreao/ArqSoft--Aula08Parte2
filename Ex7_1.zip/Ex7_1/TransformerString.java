package Ex7_1;

public abstract class TransformerString {
	
	public void RealizarTransformerString() {
	LerString();
	TransformarString();
	ImprimirString();
}

	public abstract void LerString();
	public abstract void TransformarString();
	public abstract void ImprimirString();
}